import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tech-interest-dialog',
  templateUrl: './tech-interest-dialog.component.html',
  styleUrls: ['./tech-interest-dialog.component.css']
})
export class TechInterestDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
